import java.util.ArrayList;

import java.util.Scanner;

import java.lang.Float;


public class Main 
{
	
public static void main(String[] args) {
		
ArrayList<Integer> l=new ArrayList<>();
		
Scanner sc=new Scanner(System.in);
		
int matches=sc.nextInt();
		
int total=0;
		
sc.nextLine();
		
for(int i=0;i<matches;i++)
		
    l.add(sc.nextInt());
		
for(int i:l)
		 
   total+=i;
	
System.out.println("Total: "+total);
		
double f=total/matches;
		
System.out.println("Average: "+ f);
	
	}

}