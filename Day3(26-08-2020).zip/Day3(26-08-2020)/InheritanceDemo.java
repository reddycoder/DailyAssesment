import java.util.Scanner;

class Shape{
	private String shapename;
	
	public Shape(String shapename){
		this.shapename=shapename;
	}
	
	double calculateArea() {
		
		return 0;
	}

	public String getShapename() {
		return shapename;
	}

	public void setShapename(String shapename) {
		this.shapename = shapename;
	}
	
}
class Square extends Shape{
	
	private int side;
	
	public Square(int side){
		super("Square");
		this.side=side;
		
	}
	
	double calculateArea() {
		 double area=side*side;
		 return area;
		
	}

	public int getSide() {
		return side;
	}

	public void setSide(int side) {
		this.side = side;
	}
	
}
class Rectangle extends Shape{
	
	private int length;
	private int breadth;
	
	Rectangle(int length,int breadth){
		super("Rectangle");
		this.length=length;
		this.breadth=breadth;
	}
	
	double calculateArea() {
		double area=length*breadth;
		return area;
		
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getBreadth() {
		return breadth;
	}

	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}
	
}
class Circle extends Shape{
	private int radius;
	
	Circle(int radius){
		super("Circle");
		this.radius=radius;
	}
	double calculateArea() {
		double area=3.14*radius*radius;
		return area;
		
	}
	public int getRadius() {
		return radius;
	}
	public void setRadius(int radius) {
		this.radius = radius;
	}
	
}
public class InheritanceDemo {
	
	public static void main(String args[]) {
		System.out.println("1.Rectangle\n2.Square\n3.Circle");
		System.out.println("Area Calculator-----Choose Shape");
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		switch(choice) {
		case 1:
				System.out.println("Enter Length and Breadth:");
				Rectangle r=new Rectangle(sc.nextInt(),sc.nextInt());
				System.out.println("Area of Rectangle:"+r.calculateArea());
				break;
		case 2:
				System.out.println("Enter Side of a Square:");
				Square s=new Square(sc.nextInt());
				System.out.println("Area of Square:"+s.calculateArea());
				break;
		case 3:
				System.out.println("Enter Radius of Circle:");
				Circle c=new Circle(sc.nextInt());
				System.out.println("Area of Circle:"+c.calculateArea());
				break;
		default:
				System.out.println("Exiting");
				break;
				
		}
		sc.close();
	}

}
