import java.util.Scanner;

class UserMainCode11 {
	public static Boolean validateCity(String city) {
		String str1=city.toLowerCase();
		System.out.println(str1);
		String str=city.substring(2,city.length()-2);
		for(int i=0;i<str.length();i++) {
			if(str.charAt(i)=='*')
				continue;
			else
				return false;
		}
		if((str1.charAt(0)>'a'||str1.charAt(0)<'z') && (str1.charAt(1)>'a' || str1.charAt(1)<'z') && (str1.charAt(str1.length()-2)>'a' || str1.charAt(str1.length()-2)<'z') && (str1.charAt(str1.length()-1)>'a' || str1.charAt(str1.length()-1)<'z'))
			return true;
		else
			return false;
			
	}

}

public class Validation11 {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String city=sc.nextLine();
		boolean b=UserMainCode11.validateCity(city);
		if(b)
			System.out.println("Valid");
		else
			System.out.println("InValid");
		sc.close();

	}

}
