class Main{

public static void main(String[] args){
	System.out.print("Hello World! \n"+"It's been nice knowing you. \n"+"Goodbye world! ");
}
}
