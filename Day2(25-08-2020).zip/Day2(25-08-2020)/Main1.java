import java.util.Scanner;

class Player{
	String name;
	String country;
	String skill;
}
public class Main1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Player p=new Player();
		System.out.print("Enter the Player Name: ");
		p.name=sc.nextLine();
		System.out.print("Enter the Country Name: ");
		p.country=sc.nextLine();
		System.out.print("Enter the Skill: ");
		p.skill=sc.nextLine();
		System.out.print("Player details: \nPlayer Name: " + p.name +"\n" + "Country name: "+ p.country +"\nSkill:"+p.skill);
		sc.close();
	}

}