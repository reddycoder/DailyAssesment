import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Delivery d=new Delivery();
		System.out.println("Enter the Over:");
		d.setOver(sc.nextLong());
		System.out.println("Enter the ball:");
		d.setBall(sc.nextLong());
		System.out.println("Enter the runs:");
		d.setRuns(sc.nextLong());
		sc.nextLine();
		System.out.println("Enter the Batsman:");
		d.setBatsman(sc.nextLine());
		System.out.println("Enter the bowler:");
		d.setBowler(sc.nextLine());
		System.out.println("Enter the Non Striker:");
		d.setNonstriker(sc.nextLine());
		System.out.println("Delivery Details:");
		System.out.println("Over:"+d.getOver()+"\nBall:"+d.getBall()+"\nruns:"+d.getRuns()+"\nBatsman:"+
				d.getBatsman()+"\nBowler:"+d.getBowler()+"\nNon Striker:"+d.getNonstriker());
		sc.close();
	}

}
