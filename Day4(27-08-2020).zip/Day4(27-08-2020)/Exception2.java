import java.util.Scanner;

public class Exception2 {
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		int overs;
		System.out.println("Enter Number of Overs");
		overs=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter Runs per Each Over");
		try {
			int runs[]=new int[overs];
			for(int i=0; i< runs.length; i++) 
				runs[i]=sc.nextInt();
			System.out.println("enter over Number");
			int overnum=sc.nextInt();
			System.out.println("Runs Scored in this Over is:"+runs[overnum-1]);
		}
		catch(Exception e) {
			System.out.println(e);
		}
		sc.close();
		
	}

}
