import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws Exception {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Wickets");
		int size = sc.nextInt();
		sc.nextLine();
		String w[]= new String[size];
		for(int i=0;i<size;i++) {
			System.out.println("Enter Details of Wicket"+ i+1);
			w[i]=sc.nextLine();
		}
		System.out.println("Wicket Details");
		for(int i=0;i<size;i++) {
			String[] arr=w[i].split(",");
			Wicket wt= new Wicket(Long.parseLong(arr[0]),Long.parseLong(arr[1]),arr[2],arr[3],arr[4]);
			System.out.println("Over:"+wt.getOver()+"\nBall:"+wt.getBall()+"\nWicket Type:"+wt.getWicketType()+"\nPlayer Name:"+wt.getPlayerName()+"\nBowler Name:"+wt.getBowlerName());
		}
		
		sc.close();
	}

}
