class Main{

public static void main(String[] args){
	
	int size=5;
	int white_space=size-1;
	for(int i=1;i<=size;i++)
	{
		for(int j=1;j<=size;j++){
			System.out.print("*");
		}
		System.out.print("\t \t");
		for(int k=1;k<=white_space;k++)
			System.out.print(" ");
		white_space--;
		for(int  l=1;l<=i;l++)
			System.out.print("* ");
		System.out.println("");
}
}
}
OUTPUT:

*****               *
*****              * *
*****             * * *
*****            * * * *
*****           * * * * *
