import java.util.Scanner;

class CustomeException extends Exception {
	
	CustomeException(String s){
		super(s);
	}
}
public class Abc {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Player Name:");
		String name=sc.nextLine();
		System.out.println("Enter Age:");
		int age=sc.nextInt();
		try {
			if(age<19)
				throw new CustomeException("CustomeException: InvalidAgeRangeException");
			else {
				System.out.println("Player Name:"+name);
				System.out.println("Player Age:"+age);
				sc.close();
			}
		}
		catch(CustomeException e) {
			System.out.print(e.getMessage());
		}
		
	
	}
	
}
