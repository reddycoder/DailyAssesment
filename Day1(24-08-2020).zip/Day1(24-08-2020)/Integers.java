class  Integers{
public static void main(String[] args){
inti=0;
	while(i!=37)
	System.out.print(i++ +" ");
}
}
