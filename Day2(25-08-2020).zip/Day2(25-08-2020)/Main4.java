import java.util.Scanner;

class Player1{
	String name;
	String country;
	String skill;
}
public class Main4 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Player1 p=new Player1();
		System.out.print("Enter the Player Details:\n");
		String details=sc.nextLine();
		String arr[]=details.split(",");
		System.out.print("Player details: \nPlayer Name: " + arr[0] +"\n" + "Country name: "+ arr[1] +"\nSkill:"+arr[2]);
		sc.close();
	}

}