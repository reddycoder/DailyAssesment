import java.util.*;



public class Sort 
{
	
public static void main(String[] args) {

ArrayList<Integer> l=new ArrayList<>();
		
Scanner sc=new Scanner(System.in);
		
int matches=sc.nextInt();
		
sc.nextLine();
		
for(int i=0;i<matches;i++)
		    
l.add(sc.nextInt());
		    
Collections.sort(l);
		
for(int i:l)
		    
System.out.println(" "+i);
	
}

}
