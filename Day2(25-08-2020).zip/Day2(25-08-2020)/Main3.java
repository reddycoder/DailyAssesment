import java.util.Scanner;

class Delivery{
	public long over;
	public long ball;
	public long runs;
	public String batsman;
	public String bowler;
	public String nonstriker;
	
	void displayDeliveryDetails(){
		System.out.println("Delivery Details:\nOver:"+ over +"\nBall"+ ball +"\nRuns:"+ runs +"\nBatsman:"+ batsman +"\nBowler:"+ bowler +"\nNon Striker:"+ nonstriker);
	}
	
}
public class Main3 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Delivery d= new Delivery();
		System.out.print("Enter over:");
		d.over=sc.nextLong();
		System.out.print("Enter ball:");
		d.ball=sc.nextLong();
		System.out.print("Enter runs:");
		d.runs=sc.nextLong();
		sc.nextLine();//ignoring the new line
		System.out.print("Enter Batsman Name:");
		d.batsman=sc.nextLine();
		System.out.print("Enter Bowler Name:");
		d.bowler=sc.nextLine();
		System.out.print("Enter Non Striker:");
		d.nonstriker=sc.nextLine();
		d.displayDeliveryDetails();
		sc.close();
	}

}
