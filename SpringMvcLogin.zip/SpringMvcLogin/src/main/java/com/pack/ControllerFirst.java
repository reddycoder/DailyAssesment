package com.pack;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.pack.bean.Login;

@Controller
public class ControllerFirst {
	
	@RequestMapping(value="/login")
	public String loginForm(ModelMap m) {
		Login l= new Login();
		m.addAttribute("login", l);
		return "login";
		}
	@RequestMapping(value="/check")
	public String loginCheck(@Validated @ModelAttribute("login") Login l1,BindingResult res,ModelMap m1) {
		String ret;
		if(res.hasErrors()) {
			ret="login";
		}
		else {
			m1.addAttribute("log",l1);
			ret="success";
		}
		return ret;
	}

}
