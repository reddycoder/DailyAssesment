class Inches{
	public static void main(String args[]){
		System.out.println(args[0]+" inches in cms is = " + 2.54*Double.parseDouble(args[0]));
}
}
