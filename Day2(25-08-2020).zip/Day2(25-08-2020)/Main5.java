import java.util.Scanner;

class ExtraType{
	private String name;
	private long runs;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getRuns() {
		return runs;
	}
	public void setRuns(long runs) {
		this.runs = runs;
	}
	
}
public class Main5 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		ExtraType p=new ExtraType();
		System.out.print("Enter the ExtraType Details:\n");
		String details=sc.nextLine();
		String arr[]=details.split("#");
		p.setName(arr[0]);
		long run=Long.parseLong(arr[1]);
		p.setRuns(run);
		System.out.print("Extra Type details: \nExtra Type: " + p.getName()  +"\n" + "Runs:" + p.getRuns());
	    sc.close();
	}

}