import java.util.*;

public class Venue 
{
public static void main(String[] args) {
ArrayList<String> l=new ArrayList<>();
Scanner sc=new Scanner(System.in);
int matches=sc.nextInt();
sc.nextLine();
for(int i=0;i<matches;i++)
    l.add(sc.nextLine());
String s=sc.nextLine();
System.out.println(Collections.frequency(l,s));
	
	}

}