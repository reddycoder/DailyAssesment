class Pay{
	public static void main(String args[]){
		System.out.println("total due pay is = " + Double.parseDouble(args[0])*Double.parseDouble(args[1]));
}
}
