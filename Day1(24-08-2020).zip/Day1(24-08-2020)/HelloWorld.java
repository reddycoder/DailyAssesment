Class HelloWorld{
public static void main (String args[ ]) {     
                    String name = "chenna";
System.out.println("Hello " + name);
                    }
}
