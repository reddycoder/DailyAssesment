
public class UserMainCode {
	public static Boolean validateDate(String date) {
		
		String arr[]=date.split("-");
		if(date.contains("-")) {
			if(Integer.parseInt(arr[0])>0 && Integer.parseInt(arr[0])<31 && Integer.parseInt(arr[1])>1 && Integer.parseInt(arr[1])<12)
				return true;
			else
				return false;
		}
		else
			return false;
	}

}
