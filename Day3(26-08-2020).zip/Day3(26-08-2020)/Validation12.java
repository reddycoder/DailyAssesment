import java.util.Scanner;


 class UserMainCode12 {
	public static Boolean validatePlayer(String name) {
		
		String str=name.toLowerCase();
		if(!name.contains("a")) 
				return true;
		else {
			for(int i=0;i<str.length();i++) {
				if(i%2 == 1) {
					if(str.charAt(i)=='a')
						return false;
				}
			}
		}
		return true;
	}

}

public class Validation12 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String name=sc.nextLine();
		boolean b=UserMainCode12.validatePlayer(name);
		if(b)
			System.out.println("Valid");
		else
			System.out.println("InValid");
		sc.close();

	}
}
