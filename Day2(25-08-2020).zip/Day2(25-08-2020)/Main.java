import java.util.Scanner;

class Venue{
	String name;
	String city;
}
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Venue v=new Venue();
		System.out.print("Enter the Venue Name: ");
		v.name=sc.nextLine();
		System.out.print("Enter the  Name: ");
		v.city=sc.nextLine();
		System.out.print("Venue details: \nVenue Name: " + v.name +"\n" + "city name: "+ v.city);
		sc.close();
	}

}
